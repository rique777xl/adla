import subprocess
import time
import os
import sys # Importa sys para usar sys.executable

def run_script(script_name):
    """
    Executa um script Python e imprime sua saída.
    Retorna True se a execução for bem-sucedida, False caso contrário.
    """
    print(f"\n--- Executando {script_name} ---")
    try:
        # Usa sys.executable para garantir que o interpretador Python correto seja usado.
        # Isso ajuda a evitar problemas se 'python' não estiver no PATH.
        process = subprocess.run([sys.executable, script_name], capture_output=True, text=True, check=True)
        print(f"Saída de {script_name}:\n{process.stdout}")
        if process.stderr:
            print(f"Erros de {script_name}:\n{process.stderr}")
        print(f"--- {script_name} Finalizado ---")
        return True
    except subprocess.CalledProcessError as e:
        print(f"ERRO: Falha ao executar {script_name}!")
        print(f"Comando: {' '.join(e.cmd)}")
        print(f"Código de Retorno: {e.returncode}")
        print(f"Stdout (se houver):\n{e.stdout}")
        print(f"Stderr (se houver):\n{e.stderr}")
        print(f"--- Falha crítica em {script_name}. Parando a orquestração. ---")
        return False
    except FileNotFoundError:
        print(f"ERRO: Script '{script_name}' não encontrado ou interpretador Python não acessível.")
        print(f"Certifique-se de que '{script_name}' está no mesmo diretório e 'python' está no seu PATH.")
        print(f"--- Falha crítica em {script_name}. Parando a orquestração. ---")
        return False
    except Exception as e:
        print(f"ERRO INESPERADO ao executar {script_name}: {e}")
        print(f"--- Falha crítica em {script_name}. Parando a orquestração. ---")
        return False

def main_orchestrator(cycles=None, delay_seconds=5):
    """
    Orquestra a execução alternada de treiner-simulator-gemini.py e adla.py.
    Define cycles=None para rodar indefinidamente.
    """
    print("Iniciando o orquestrador de scripts...")
    if cycles is None:
        print("Rodando em modo contínuo (Ctrl+C para parar).")
    else:
        print(f"Serão executados {cycles} ciclos.")
    print(f"Com um atraso de {delay_seconds} segundos entre as execuções de scripts.")

    # Cria um adla.py dummy se não existir, para que o orquestrador possa testar.
    # Se você já tem seu adla.py, este bloco não fará nada.
    if not os.path.exists('adla.py'):
        print("\n--- ATENÇÃO: 'adla.py' não encontrado. Criando um arquivo dummy para demonstração. ---")
        print("Você pode substituí-lo pelo seu 'adla.py' real.")
        with open('adla.py', 'w') as f:
            f.write("import os\n")
            f.write("import time\n")
            f.write("print('Olá do adla.py! Este é o segundo script.')\n")
            f.write("if not os.path.exists('current_withdrawal_rate.txt'):\n")
            f.write("    with open('current_withdrawal_rate.txt', 'w') as fw:\n")
            f.write("        fw.write('0.20')\n")
            f.write("else:\n")
            f.write("    with open('current_withdrawal_rate.txt', 'r') as fr:\n")
            f.write("        rate = float(fr.read().strip())\n")
            f.write("    new_rate = round(max(0.05, min(0.95, rate + (0.01 if rate < 0.5 else -0.01))), 2)\n")
            f.write("    with open('current_withdrawal_rate.txt', 'w') as fw:\n")
            f.write("        fw.write(str(new_rate))\n")
            f.write(f"print(f'adla.py: Taxa de saque simulada atualizada para {{new_rate:.2f}}')\n")
        print("--- 'adla.py' dummy criado. ---")

    cycle_count = 0
    while True:
        cycle_count += 1
        print(f"\n===== Ciclo {cycle_count} =====")

        # Executa treiner-simulator-gemini.py
        if not run_script('treiner-simulator-gemini.py'):
            break # Para se houver um erro crítico

        time.sleep(delay_seconds) # Pausa entre os scripts

        # Executa adla.py
        if not run_script('adla.py'):
            break # Para se houver um erro crítico

        if cycles is not None and cycle_count >= cycles:
            print(f"\nTotal de {cycles} ciclos concluídos. Encerrando.")
            break

        print(f"\nPróximo ciclo em {delay_seconds} segundos...")
        time.sleep(delay_seconds) # Pausa antes do próximo ciclo

    print("\nOrquestração finalizada.")

if __name__ == "__main__":
    # Configurações:
    # cycles=None para rodar indefinidamente (como um cron job contínuo).
    # cycles=3 para rodar 3 vezes e parar.
    # delay_seconds é o tempo de espera entre as execuções dos scripts.
    main_orchestrator(cycles=None, delay_seconds=10) # Rodará indefinidamente com 10 segundos de atraso