import os
import time

print('Olá de adla.py - Isso representa o segundo modelo de IA.')

# Exemplo: adla.py pode ser outra IA que determina a taxa de saque
# ou executa outras ações que influenciam o treiner-simulator-gemini.py.
# Para demonstração, vamos apenas fazer com que ele modifique o arquivo de taxa de saque.

# Garante que current_withdrawal_rate.txt exista
if not os.path.exists('current_withdrawal_rate.txt'):
    with open('current_withdrawal_rate.txt', 'w') as f:
        f.write('0.20') # Taxa de saque padrão

with open('current_withdrawal_rate.txt', 'r') as f:
    current_rate = float(f.read().strip())

# Simula adla.py ajustando a taxa de saque
# Por exemplo, aumente ligeiramente se estiver baixa, diminua se estiver alta
new_rate = round(max(0.05, min(0.95, current_rate + (0.01 if current_rate < 0.5 else -0.01))), 2)

with open('current_withdrawal_rate.txt', 'w') as f:
    f.write(str(new_rate))

print(f"adla.py: Taxa de saque atualizada para {new_rate:.2f}")